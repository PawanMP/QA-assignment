<html>
<head>
  <title>Store Results</title>
  <style>
  .searchResultsContainer{
    font-size: 30px;
}
    .box {
        font-size: 30px;
     border: 1px solid #000;
      padding: 5px;
      width: 300px;
      background-color: #f1f1f1;
    }
  </style>
    <style>
       
        strong {
    font-weight: bold;
    color: red; 
}
.button {
      display: inline-block;
      padding: 20px 30px;
      background-color: blue;
      color: white;
      text-decoration: none;
      font-size: 16px;
      border-radius: 5px;
    }
    .button2 {
      display: inline-block;
      padding: 20px 30px;
      background-color: red;
      color: white;
      text-decoration: none;
      font-size: 16px;
      border-radius: 5px;
    }
      </style>
    
</head>
<body background="bgn.avif">
    <Center><h1 style="color: yellow;font-size: 80px;">Store</h1></Center>
 <?php
 ini_set('display_errors', 'off');
 include 'dbconnection.php';
 $code=$_GET["code"];
 $lg=$_GET["length"];

if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
 }
 else{
     //connection confirmed
     echo ".<br/>";
 $sql = "SELECT * FROM curtain_material where Material_code='$code'";
     $result = $conn->query($sql);
     if ($result->num_rows > 0) {
     // output data of each row
     while($row = $result->fetch_assoc()) {
         //echo "<br><strong>material:</strong> <br>""<br>";
         if($lg<=$row["amount_current"]){
          echo'<p style="font-family: Arial, sans-serif; font-size: 30px; color: blue;text-align: center;">Can use the currently using roll</p>';
        }
        else{
          echo '<p style="font-family: Arial, sans-serif; font-size: 30px;color: red;text-align: center;">cannot use currently using roll please switch to a new roll .</p>';
        }
         ?>
         
         <center>
         <div id="searchResultsContainer">
         <form method="GET">
            <p style="color: green;font-size: 30px;">Material name</p>
         <input type="text" name="type"value="<?php echo $row["type"]  ?>"/></div>
         
         <p style="color: green;font-size: 30px;">Number of rolls remaining</p>
         <input type="text" name="type"value="<?php echo $row["No.of_rolls"]  ?>"/></div>
            <p style="color: green;font-size: 30px;">Meter amount in using roll</p>
            <input type="text" name="type"value="<?php echo $row["amount_current"]  ?>"/>
            
            
     </div>
     </center>
    
         <?php
         
        }
 } else {
     echo ".";
 }
 
 
 
 $conn->close();
 }
 ?>
<Center><blockquote style="margin-right: 300px;"> <a class="button" href="continue.html" style="text-align: right;" >Using current roll</a><br></Center>  
<Center><blockquote style="margin-left: 300px;"> <a class="button2" href="rollselection.html" style="text-align: right;" >Switch to a new roll</a><br></Center>

</body>
</html>