<?php
            include 'dbconnection.php';
            $rno=$_GET["receiptNo"];
            $tel=$_GET["tel"];       
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

else{
	//connection confirmed
	echo "Connected successfully<br/>";
	//Write insert query
	$sql = "insert into receipt_details 
	values ('".$rno."','".$tel."')";
	//insert values to DB
	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	//connection closed.
	$conn->close();
}




        
            ?>