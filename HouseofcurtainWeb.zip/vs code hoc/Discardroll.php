<?php
            include 'dbconnection.php';
            $len=$_GET["length"];
            $code=$_GET["code"];       
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            // Query 1: Insert data
$sql1 = "UPDATE curtain_material SET  `No.of_rolls`= `No.of_rolls` - 1 WHERE Material_code = '$code'";
if ($conn->query($sql1) === TRUE) {
    echo "Query 1 executed successfully.<br>";
} else {
    echo "Error executing Query 1: " . $conn->error . "<br>";
}

// Query 2: Update data
$sql2 = "UPDATE curtain_material SET  amount_current = 180 WHERE Material_code = '$code'";
if ($conn->query($sql2) === TRUE) {
    echo "Query 2 executed successfully.<br>";
} else {
    echo "Error executing Query 2: " . $conn->error . "<br>";
}

// Query 3: Delete data
$sql3 = "UPDATE curtain_material SET amount_current = amount_current - $len WHERE Material_code = '$code'";
if ($conn->query($sql3) === TRUE) {
    echo "Query 3 executed successfully.<br>";
} else {
    echo "Error executing Query 3: " . $conn->error . "<br>";
}

// Close the database connection
$conn->close();
            /*else{
                echo "connection confirmed";
                echo ".<br/>";
            $sql1 = "UPDATE curtain_material SET  `No.of_rolls`= `No.of_rolls` - 1 WHERE Material_code = '$code'";
            
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $sql2 = "UPDATE curtain_material SET  amount_current = 180 WHERE Material_code = '$code'";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $sql3 = "UPDATE curtain_material SET amount_current = amount_current - $len WHERE Material_code = '$code'";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            //connection closed.
            $conn->close();
            }*/


        
            ?>