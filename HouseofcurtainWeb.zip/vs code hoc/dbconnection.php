<?php

$servername = "localhost";
$username = "root";
$password = "";
$databasename = "houseofcurtain";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $databasename);

?>