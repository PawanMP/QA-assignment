<?php
            include 'dbconnection.php';
            $len=$_GET["length"];
            $code=$_GET["code"];       
            
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            else{
                echo "connection confirmed";
                echo ".<br/>";
            $sql = "UPDATE curtain_material SET amount_current = amount_current - $len WHERE Material_code = '$code'";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            //connection closed.
            $conn->close();
            }
        
            ?>