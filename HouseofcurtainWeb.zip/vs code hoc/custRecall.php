<?php
 include 'dbconnection.php';
 $no=$_GET["no"];
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM receipt_details where telno='$no'";

$result = $conn->query($sql);


if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {
        
        echo "receiptno: " . $row["receiptNo"] .  "<br>";
        
    }
} else {
    echo "No data found in the table.";
}


$conn->close();
?>
